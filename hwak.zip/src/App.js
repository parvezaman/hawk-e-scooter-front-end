import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Users from './Pages/Users/Users';

function App() {
  return (
    <div>
        <Users />
    </div>
  );
}

export default App;
